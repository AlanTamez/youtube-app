//AIzaSyCv-wULnLQSH9JYKj3pSdIjvMXt23hmtoU
let key = "AIzaSyCv-wULnLQSH9JYKj3pSdIjvMXt23hmtoU";
//Variables globales para utilizarlas fuera de las funciones
let dato;
let infob;

function buildFetch(link, callback) {
	//proceso de la peticion
	fetch(link)
		.then(response => {
			if (response.ok) {
				return response.json();
			}
			else {
				throw new Error("Something went wrong. Try again later.");
			}
		})
		.then(responseJson =>{
			//aquí hace la llamada a la funcion display con la informacion responseJson
			callback(responseJson);
		})
		.catch(err =>{
			$("#results").html(err.message);
		});
}

function display(data){
	//Proceso de desplegar la lista de videos
	$("#videos").html("");
	for(let i = 0; i < data.items.length; i++){
    	$("#videos").append(`
    						<div class="elementos">
    							<div class = "titulo">
	                    			<a href = "https://www.youtube.com/watch?v=${data.items[i].id.videoId}"" target = "-blank">
	      								<h3>${data.items[i].snippet.title}</h3>
	                    			</a>
    							</div>
    							<div class = "imagen">
    								<a href = "https://www.youtube.com/watch?v=${data.items[i].id.videoId}"" target = "-blank">
    								<img style="width:15%" src="${data.items[i].snippet.thumbnails.default.url}"/>
    								</a>
    							</div>
    						</div>



    						`);
    }
    infob = data; 
}

$("#butSub").click(function(e){				
	e.preventDefault();	
	dato = $("#searchTerm").val();
	//Si ya hay algo escrito hace el url con el dato y la key ya creada									
	if(dato != "")
    {
      let url = `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q=${dato}&type=video&key=${key}`;
      buildFetch(url, display);
    }
});

$("#Nextbutton").click(function(n){
	//Si existe informacion despues de la lista de 10 procede al fetch
	if(infob.nextPageToken){
		let url = `https://www.googleapis.com/youtube/v3/search?pageToken=${infob.nextPageToken}&part=snippet&maxResults=10&q=${dato}&type=video&key=${key}`;
		buildFetch(url, display);
	}
});

$("#Prevbutton").click(function(p){
	//Si existe informacion antes de la lista de 10 procede al fetch
	if(infob.prevPageToken){
		let url = `https://www.googleapis.com/youtube/v3/search?pageToken=${infob.prevPageToken}&part=snippet&maxResults=10&q=${dato}&type=video&key=${key}`;
		buildFetch(url, display);
	}
});
//maxResults permite que se haga la lista de 10 videos máximo por página
//pagetoken permite cambiar de pagina antes o despues
//type permite solo mostrar videos o tambien canales